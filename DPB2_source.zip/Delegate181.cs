using System.Globalization;

internal delegate string Delegate181(object object_0, string string_0, CultureInfo cultureInfo_0);
