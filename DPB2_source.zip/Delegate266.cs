internal delegate string Delegate266(string string_0, object object_0, object object_1, object object_2);
