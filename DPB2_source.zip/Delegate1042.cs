using System.Windows;

internal delegate object Delegate1042(ref DependencyPropertyChangedEventArgs dependencyPropertyChangedEventArgs_0);
