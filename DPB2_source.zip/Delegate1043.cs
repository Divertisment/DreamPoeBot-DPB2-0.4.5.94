using System.Windows;

internal delegate object Delegate1043(ref DependencyPropertyChangedEventArgs dependencyPropertyChangedEventArgs_0);
